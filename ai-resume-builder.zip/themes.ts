
export interface Theme {
  name: string;
  className: string;
}

export const themes: Theme[] = [
  { name: 'Modern', className: 'theme-modern' },
  { name: 'Classic', className: 'theme-classic' },
  { name: 'Creative', className: 'theme-creative' },
];

// Using a CSS string is a simple way to inject theme styles without a complex CSS-in-JS setup.
// In a larger app, you might use CSS variables or a dedicated theming library.
export const themeStyles = `
  /* Modern Theme */
  .theme-modern.resume-container { font-family: 'Inter', sans-serif; }
  .theme-modern .primary-color { color: #4f46e5; }
  .theme-modern .primary-bg { background-color: #4f46e5; }
  .theme-modern .border-color { border-color: #e0e7ff; }
  .theme-modern .section-title { text-transform: uppercase; letter-spacing: 0.05em; border-bottom-width: 2px; }
  .theme-modern .name { font-size: 2.25rem; font-weight: 700; }
  .theme-modern .header-layout { flex-direction: row; }

  /* Classic Theme */
  .theme-classic.resume-container { font-family: 'Georgia', serif; }
  .theme-classic .primary-color { color: #111827; }
  .theme-classic .primary-bg { background-color: #111827; }
  .theme-classic .border-color { border-color: #d1d5db; }
  .theme-classic .section-title { text-align: center; font-variant: small-caps; letter-spacing: 0.1em; border-bottom-width: 1px; }
  .theme-classic .name { font-size: 2.25rem; font-weight: 600; text-align: center; width: 100%; }
  .theme-classic .job-title { text-align: center; width: 100%; }
  .theme-classic .header-layout { flex-direction: column; }
  .theme-classic .header-content { align-items: center; }
  .theme-classic .contact-info { justify-content: center; flex-wrap: wrap; }

  /* Creative Theme */
  .theme-creative.resume-container { font-family: 'Roboto Mono', monospace; }
  .theme-creative .primary-color { color: #db2777; } /* Pink */
  .theme-creative .primary-bg { background-color: #db2777; }
  .theme-creative .border-color { border-color: #fbcfe8; }
  .theme-creative .section-title { font-weight: 700; border-left-width: 4px; padding-left: 0.5rem; }
  .theme-creative .name { font-size: 2.125rem; background-color: #fdf2f8; padding: 0.25rem 0.5rem; display: inline; }
  .theme-creative .header-layout { flex-direction: row; }
  .theme-creative .skill-bar-bg { background-color: #fce7f3; }
  .theme-creative .skill-bar-fill { background-color: #db2777; }

  .prose ul > li::marker { color: var(--tw-prose-body); }
  .dark .prose ul > li::marker { color: var(--tw-prose-invert-body); }
  .theme-modern .prose ul > li::marker { color: #4f46e5; }
  .theme-classic .prose ul > li::marker { color: #111827; }
  .theme-creative .prose ul > li::marker { color: #db2777; }
`;
