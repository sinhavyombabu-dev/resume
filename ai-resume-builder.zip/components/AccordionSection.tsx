
import React, { useState } from 'react';
import { ChevronDownIcon } from './icons/ChevronDownIcon';
import { DragHandleIcon } from './icons/DragHandleIcon';

interface AccordionSectionProps {
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  isDraggable: boolean;
  isDragging?: boolean;
  onDragStart?: () => void;
  onDragOver?: (e: React.DragEvent) => void;
  onDrop?: () => void;
  onDragEnd?: () => void;
}

export const AccordionSection: React.FC<AccordionSectionProps> = ({ 
  title, icon, children, isDraggable, isDragging, onDragStart, onDragOver, onDrop, onDragEnd 
}) => {
  const [isOpen, setIsOpen] = useState(true);

  return (
    <div
      draggable={isDraggable}
      onDragStart={onDragStart}
      onDragOver={onDragOver}
      onDrop={onDrop}
      onDragEnd={onDragEnd}
      className={`bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden transition-opacity ${isDragging ? 'dragging' : ''}`}
    >
      <div
        className="w-full flex justify-between items-center p-4 text-left font-semibold text-lg text-gray-800 dark:text-white"
      >
        <div className="flex items-center space-x-3">
          {isDraggable && <DragHandleIcon className="cursor-grab text-gray-400" />}
          <span className="text-indigo-500">{icon}</span>
          <span>{title}</span>
        </div>
        <button onClick={() => setIsOpen(!isOpen)} className="p-1">
            <ChevronDownIcon className={`w-6 h-6 transform transition-transform ${isOpen ? 'rotate-180' : ''}`} />
        </button>
      </div>
      <div
        className={`transition-all duration-300 ease-in-out overflow-hidden ${
          isOpen ? 'max-h-[2000px] opacity-100' : 'max-h-0 opacity-0'
        }`}
      >
        <div className="p-4 border-t border-gray-200 dark:border-gray-700">
          {children}
        </div>
      </div>
    </div>
  );
};
