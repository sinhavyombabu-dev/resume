
export interface PersonalDetails {
  fullName: string;
  jobTitle: string;
  email: string;
  phone: string;
  address: string;
  website: string;
  summary: string; // Can contain HTML
  photo: string | null;
}

export interface Experience {
  id: string;
  jobTitle: string;
  company: string;
  location: string;
  startDate: string;
  endDate: string;
  description: string; // Can contain HTML
}

export interface Education {
  id: string;
  degree: string;
  institution: string;
  location: string;
  startDate: string;
  endDate: string;
  description: string;
}

export interface Skill {
  id: string;
  name: string;
  level: number; // 1-5 scale
}

export interface CustomSection {
    id: string; // Will be prefixed with 'custom-'
    title: string;
    content: string; // Can contain HTML
}

export interface ResumeData {
  personal: PersonalDetails;
  experience: Experience[];
  education: Education[];
  skills: Skill[];
  customSections: CustomSection[];
}

export type SectionKey = 'experience' | 'education' | 'skills' | 'customSections' | string;
