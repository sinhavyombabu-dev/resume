
import React from 'react';
import type { ResumeData, CustomSection } from '../types';
import { Input } from './Input';
import { RichTextInput } from './RichTextInput';
import { PlusCircleIcon } from './icons/PlusCircleIcon';
import { TrashIcon } from './icons/TrashIcon';

interface CustomSectionsFormProps {
  customSections: CustomSection[];
  setResumeData: React.Dispatch<React.SetStateAction<ResumeData>>;
}

export const CustomSectionsForm: React.FC<CustomSectionsFormProps> = ({ customSections, setResumeData }) => {
  
  const updateSection = (id: string, name: 'title' | 'content', value: string) => {
    setResumeData(prev => ({
      ...prev,
      customSections: prev.customSections.map(sec => sec.id === id ? { ...sec, [name]: value } : sec)
    }));
  };

  const addSection = () => {
    const newSection: CustomSection = {
      id: `custom-${Date.now()}`,
      title: 'New Section',
      content: ''
    };
    setResumeData(prev => ({
      ...prev,
      customSections: [...prev.customSections, newSection]
    }));
  };

  const removeSection = (id: string) => {
    setResumeData(prev => ({
      ...prev,
      customSections: prev.customSections.filter(sec => sec.id !== id)
    }));
  };

  return (
    <div className="space-y-6">
      {customSections.map(sec => (
        <div key={sec.id} className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg space-y-4 relative">
            <Input 
                label="Section Title" 
                name="title" 
                value={sec.title} 
                onChange={e => updateSection(sec.id, 'title', e.target.value)}
            />
            <RichTextInput
                label="Content"
                value={sec.content}
                onChange={value => updateSection(sec.id, 'content', value)}
            />
            <button onClick={() => removeSection(sec.id)} className="absolute top-2 right-2 text-red-500 hover:text-red-700">
                <TrashIcon />
            </button>
        </div>
      ))}
      <button onClick={addSection} className="flex items-center space-x-2 text-indigo-600 hover:text-indigo-800 font-semibold">
        <PlusCircleIcon />
        <span>Add Custom Section</span>
      </button>
    </div>
  );
};
