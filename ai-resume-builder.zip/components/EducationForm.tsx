
import React from 'react';
import type { ResumeData, Education } from '../types';
import { Input } from './Input';
import { PlusCircleIcon } from './icons/PlusCircleIcon';
import { TrashIcon } from './icons/TrashIcon';

interface EducationFormProps {
  education: Education[];
  setResumeData: React.Dispatch<React.SetStateAction<ResumeData>>;
}

export const EducationForm: React.FC<EducationFormProps> = ({ education, setResumeData }) => {
  
  const handleChange = (id: string, e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setResumeData(prev => ({
      ...prev,
      education: prev.education.map(edu => edu.id === id ? { ...edu, [name]: value } : edu)
    }));
  };

  const addEducation = () => {
    const newEducation: Education = {
      id: `edu-${Date.now()}`,
      degree: '',
      institution: '',
      location: '',
      startDate: '',
      endDate: '',
      description: ''
    };
    setResumeData(prev => ({
      ...prev,
      education: [...prev.education, newEducation]
    }));
  };

  const removeEducation = (id: string) => {
    setResumeData(prev => ({
      ...prev,
      education: prev.education.filter(edu => edu.id !== id)
    }));
  };

  return (
    <div className="space-y-6">
      {education.map(edu => (
        <div key={edu.id} className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg space-y-4 relative">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input label="Degree / Field of Study" name="degree" value={edu.degree} onChange={e => handleChange(edu.id, e)} />
            <Input label="Institution" name="institution" value={edu.institution} onChange={e => handleChange(edu.id, e)} />
            <Input label="Location" name="location" value={edu.location} onChange={e => handleChange(edu.id, e)} />
            <div className="grid grid-cols-2 gap-4">
              <Input label="Start Date" name="startDate" value={edu.startDate} onChange={e => handleChange(edu.id, e)} />
              <Input label="End Date" name="endDate" value={edu.endDate} onChange={e => handleChange(edu.id, e)} />
            </div>
          </div>
          <button onClick={() => removeEducation(edu.id)} className="absolute top-2 right-2 text-red-500 hover:text-red-700">
            <TrashIcon />
          </button>
        </div>
      ))}
      <button onClick={addEducation} className="flex items-center space-x-2 text-indigo-600 hover:text-indigo-800 font-semibold">
        <PlusCircleIcon />
        <span>Add Education</span>
      </button>
    </div>
  );
};
