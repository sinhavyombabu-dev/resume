
import React from 'react';
export const SparklesIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <path d="M12 2L14.09 8.26 20.34 10.34 14.09 12.41 12 18.66 9.91 12.41 3.66 10.34 9.91 8.26 12 2z"></path>
    <path d="M4 4 L6 6"></path>
    <path d="M18 4 L20 6"></path>
    <path d="M4 18 L6 20"></path>
    <path d="M18 18 L20 20"></path>
  </svg>
);
