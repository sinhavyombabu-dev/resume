
import React from 'react';
import type { ResumeData, SectionKey } from '../types';
import { AccordionSection } from './AccordionSection';
import { PersonalDetailsForm } from './PersonalDetailsForm';
import { ExperienceForm } from './ExperienceForm';
import { EducationForm } from './EducationForm';
import { SkillsForm } from './SkillsForm';
import { CustomSectionsForm } from './CustomSectionsForm';
import { UserIcon } from './icons/UserIcon';
import { BriefcaseIcon } from './icons/BriefcaseIcon';
import { GraduationCapIcon } from './icons/GraduationCapIcon';
import { WrenchIcon } from './icons/WrenchIcon';
import { PlusSquareIcon } from './icons/PlusSquareIcon';

interface ResumeFormProps {
  resumeData: ResumeData;
  setResumeData: React.Dispatch<React.SetStateAction<ResumeData>>;
  sectionOrder: SectionKey[];
  draggedItem: SectionKey | null;
  dragOverItem: SectionKey | null;
  onDragStart: (key: SectionKey) => void;
  onDragOver: (e: React.DragEvent, key: SectionKey) => void;
  onDrop: (key: SectionKey) => void;
  onDragEnd: () => void;
}

export const ResumeForm: React.FC<ResumeFormProps> = (props) => {
  const { 
    resumeData, 
    setResumeData, 
    sectionOrder,
    draggedItem,
    dragOverItem,
    onDragStart,
    onDragOver,
    onDrop,
    onDragEnd,
  } = props;
  
  const sectionConfig = {
    experience: {
      title: 'Experience',
      icon: <BriefcaseIcon />,
      component: <ExperienceForm experience={resumeData.experience} setResumeData={setResumeData} />
    },
    education: {
      title: 'Education',
      icon: <GraduationCapIcon />,
      component: <EducationForm education={resumeData.education} setResumeData={setResumeData} />
    },
    skills: {
      title: 'Skills',
      icon: <WrenchIcon />,
      component: <SkillsForm skills={resumeData.skills} setResumeData={setResumeData} />
    },
    customSections: {
        title: 'Custom Sections',
        icon: <PlusSquareIcon />,
        component: <CustomSectionsForm customSections={resumeData.customSections} setResumeData={setResumeData} />
    }
  };

  const reorderableSections = sectionOrder.map(key => {
    if (key.startsWith('custom-')) return null; // Handled within CustomSectionsForm
    const config = sectionConfig[key as keyof typeof sectionConfig];
    if (!config) return null;
    return (
        <React.Fragment key={key}>
          {draggedItem && dragOverItem === key && draggedItem !== key && (
              <div className="drop-indicator"></div>
          )}
          <AccordionSection
            title={config.title}
            icon={config.icon}
            isDraggable={true}
            isDragging={draggedItem === key}
            onDragStart={() => onDragStart(key)}
            onDragOver={(e) => onDragOver(e, key)}
            onDrop={() => onDrop(key)}
            onDragEnd={onDragEnd}
          >
            {config.component}
          </AccordionSection>
        </React.Fragment>
    );
  }).filter(Boolean);

  return (
    <div className="space-y-6">
      <AccordionSection title="Personal Details" icon={<UserIcon />} isDraggable={false}>
        <PersonalDetailsForm personal={resumeData.personal} setResumeData={setResumeData} />
      </AccordionSection>

      {reorderableSections}
    </div>
  );
};
