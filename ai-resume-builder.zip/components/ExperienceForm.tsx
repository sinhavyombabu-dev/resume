
import React from 'react';
import type { ResumeData, Experience } from '../types';
import { Input } from './Input';
import { AIAssistButton } from './AIAssistButton';
import { PlusCircleIcon } from './icons/PlusCircleIcon';
import { TrashIcon } from './icons/TrashIcon';
import { RichTextInput } from './RichTextInput';

interface ExperienceFormProps {
  experience: Experience[];
  setResumeData: React.Dispatch<React.SetStateAction<ResumeData>>;
}

export const ExperienceForm: React.FC<ExperienceFormProps> = ({ experience, setResumeData }) => {
  
  const handleChange = (id: string, e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    updateExperience(id, name, value);
  };
  
  const handleRichTextChange = (id: string, name: string, value: string) => {
    updateExperience(id, name, value);
  };

  const updateExperience = (id: string, name: string, value: string) => {
     setResumeData(prev => ({
      ...prev,
      experience: prev.experience.map(exp => exp.id === id ? { ...exp, [name]: value } : exp)
    }));
  }

  const handleDescriptionUpdate = (id: string, newDescription: string) => {
     setResumeData(prev => ({
      ...prev,
      experience: prev.experience.map(exp => exp.id === id ? { ...exp, description: newDescription } : exp)
    }));
  };

  const addExperience = () => {
    const newExperience: Experience = {
      id: `exp-${Date.now()}`,
      jobTitle: '',
      company: '',
      location: '',
      startDate: '',
      endDate: '',
      description: ''
    };
    setResumeData(prev => ({
      ...prev,
      experience: [...prev.experience, newExperience]
    }));
  };

  const removeExperience = (id: string) => {
    setResumeData(prev => ({
      ...prev,
      experience: prev.experience.filter(exp => exp.id !== id)
    }));
  };

  return (
    <div className="space-y-6">
      {experience.map(exp => (
        <div key={exp.id} className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg space-y-4 relative">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input label="Job Title" name="jobTitle" value={exp.jobTitle} onChange={e => handleChange(exp.id, e)} />
            <Input label="Company" name="company" value={exp.company} onChange={e => handleChange(exp.id, e)} />
            <Input label="Location" name="location" value={exp.location} onChange={e => handleChange(exp.id, e)} />
            <div className="grid grid-cols-2 gap-4">
              <Input label="Start Date" name="startDate" value={exp.startDate} onChange={e => handleChange(exp.id, e)} />
              <Input label="End Date" name="endDate" value={exp.endDate} onChange={e => handleChange(exp.id, e)} />
            </div>
          </div>
          <div className="relative">
            <RichTextInput 
                label="Description"
                value={exp.description}
                onChange={(value) => handleRichTextChange(exp.id, 'description', value)}
            />
            <AIAssistButton 
                field="job description"
                context={JSON.stringify({jobTitle: exp.jobTitle, company: exp.company})}
                onGeneratedText={(text) => handleDescriptionUpdate(exp.id, text)} />
          </div>
          <button onClick={() => removeExperience(exp.id)} className="absolute top-2 right-2 text-red-500 hover:text-red-700">
            <TrashIcon />
          </button>
        </div>
      ))}
      <button onClick={addExperience} className="flex items-center space-x-2 text-indigo-600 hover:text-indigo-800 font-semibold">
        <PlusCircleIcon />
        <span>Add Experience</span>
      </button>
    </div>
  );
};
