import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

// FIX: Refactored to align with @google/genai coding guidelines.
// The API key is assumed to be available in process.env.API_KEY and pre-configured.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function generateResumeContent(prompt: string): Promise<string> {
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        temperature: 0.7,
        topP: 0.9,
      }
    });
    
    const text = response.text;
    if (text) {
        return text.trim();
    }
    
    throw new Error('No content generated or unexpected response format.');

  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error("Failed to generate content from Gemini API.");
  }
}
