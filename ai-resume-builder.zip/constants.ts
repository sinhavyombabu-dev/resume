
import type { ResumeData, SectionKey } from './types';

export const initialResumeData: ResumeData = {
  personal: {
    fullName: 'Amelia Chen',
    jobTitle: 'Senior Frontend Engineer',
    email: 'amelia.chen@email.com',
    phone: '(555) 123-4567',
    address: 'San Francisco, CA',
    website: 'ameliachen.dev',
    summary: 'Innovative Senior Frontend Engineer with 8+ years of experience building and maintaining responsive and scalable web applications. Proficient in React, TypeScript, and modern JavaScript frameworks. Passionate about creating intuitive user experiences and collaborating in agile environments to deliver high-quality software.',
    photo: null,
  },
  experience: [
    {
      id: 'exp1',
      jobTitle: 'Senior Frontend Engineer',
      company: 'InnovateTech Solutions',
      location: 'San Francisco, CA',
      startDate: 'Jan 2020',
      endDate: 'Present',
      description: '<ul><li>Led the development of a new customer-facing dashboard using React and TypeScript, resulting in a 20% increase in user engagement.</li><li>Mentored junior developers and conducted code reviews to ensure high-quality code and adherence to best practices.</li><li>Collaborated with UX/UI designers to implement complex, interactive features and improve overall application performance.</li></ul>'
    },
    {
      id: 'exp2',
      jobTitle: 'Frontend Developer',
      company: 'Digital Creations Inc.',
      location: 'Boston, MA',
      startDate: 'Jun 2016',
      endDate: 'Dec 2019',
      description: '<ul><li>Developed and maintained client websites using HTML, CSS, and JavaScript (ES6+).</li><li>Worked closely with the backend team to integrate RESTful APIs.</li><li>Improved website loading speeds by 30% through code optimization and image compression techniques.</li></ul>'
    }
  ],
  education: [
    {
      id: 'edu1',
      degree: 'B.S. in Computer Science',
      institution: 'Northeastern University',
      location: 'Boston, MA',
      startDate: 'Sep 2012',
      endDate: 'May 2016',
      description: 'Graduated with honors. Relevant coursework: Data Structures, Algorithms, Web Development, Human-Computer Interaction.'
    }
  ],
  skills: [
    { id: 'skill1', name: 'React & Next.js', level: 5 },
    { id: 'skill2', name: 'TypeScript', level: 5 },
    { id: 'skill3', name: 'Tailwind CSS', level: 4 },
    { id: 'skill4', name: 'Node.js', level: 3 },
    { id: 'skill5', name: 'UI/UX Design', level: 4 },
    { id: 'skill6', name: 'Agile Methodologies', level: 5 },
  ],
  customSections: [],
};

export const initialSectionOrder: SectionKey[] = ['experience', 'education', 'skills'];
