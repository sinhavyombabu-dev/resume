import React, { useState, useCallback } from 'react';
import { generateResumeContent } from '../services/geminiService';
import { SparklesIcon } from './icons/SparklesIcon';
import { LoadingSpinner } from './LoadingSpinner';

interface AIModalProps {
  field: string;
  context: string;
  onClose: () => void;
  onInsertText: (text: string) => void;
}

export const AIModal: React.FC<AIModalProps> = ({ field, context, onClose, onInsertText }) => {
  const [prompt, setPrompt] = useState('');
  const [generatedText, setGeneratedText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    setGeneratedText('');
    try {
        const fullPrompt = `Based on the following context: ${context}, write a compelling ${field}. User's request: "${prompt}". Make it professional and concise. For job descriptions, use HTML list items (e.g., '<ul><li>Responsibility 1</li><li>Responsibility 2</li></ul>'). Do not use markdown.`;
        const result = await generateResumeContent(fullPrompt);
        setGeneratedText(result);
    } catch (err) {
        // FIX: Updated error message to be more generic and not mention the API key,
        // as per the coding guidelines.
        setError('Failed to generate content. Please try again.');
        console.error(err);
    } finally {
        setIsLoading(false);
    }
  }, [context, field, prompt]);
  
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl w-full max-w-2xl transform transition-all">
        <div className="p-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold flex items-center"><SparklesIcon className="mr-2" /> AI Assistant - {field}</h2>
            <button onClick={onClose} className="text-gray-500 hover:text-gray-800 dark:hover:text-gray-200 text-2xl leading-none">&times;</button>
          </div>
          <div className="space-y-4">
            <div>
              <label htmlFor="ai-prompt" className="block text-sm font-medium text-gray-700 dark:text-gray-300">Your Prompt</label>
              <input
                id="ai-prompt"
                type="text"
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder={`e.g., "highlight my skills in teamwork and leadership"`}
                className="mt-1 block w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>
            <button
              onClick={handleGenerate}
              disabled={isLoading || !prompt}
              className="w-full flex justify-center items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-gray-400 disabled:cursor-not-allowed"
            >
              {isLoading ? <LoadingSpinner /> : 'Generate'}
            </button>
            {error && <p className="text-sm text-red-500">{error}</p>}
            {generatedText && (
              <div>
                <h3 className="text-lg font-semibold mb-2">Generated Content</h3>
                <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-md max-h-48 overflow-y-auto border dark:border-gray-700">
                  <p className="text-sm whitespace-pre-wrap">{generatedText}</p>
                </div>
              </div>
            )}
          </div>
        </div>
        <div className="bg-gray-50 dark:bg-gray-700 px-6 py-3 flex justify-end space-x-3">
            <button onClick={onClose} type="button" className="py-2 px-4 border border-gray-300 dark:border-gray-500 rounded-md shadow-sm text-sm font-medium text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-600 focus:outline-none">
                Cancel
            </button>
            <button 
                onClick={() => onInsertText(generatedText)} 
                disabled={!generatedText}
                className="py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none disabled:bg-gray-400"
            >
                Insert Text
            </button>
        </div>
      </div>
    </div>
  );
};