
import React from 'react';
import type { ResumeData, PersonalDetails } from '../types';
import { Input } from './Input';
import { AIAssistButton } from './AIAssistButton';
import { RichTextInput } from './RichTextInput';

interface PersonalDetailsFormProps {
  personal: PersonalDetails;
  setResumeData: React.Dispatch<React.SetStateAction<ResumeData>>;
}

export const PersonalDetailsForm: React.FC<PersonalDetailsFormProps> = ({ personal, setResumeData }) => {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setResumeData(prev => ({
      ...prev,
      personal: { ...prev.personal, [name]: value }
    }));
  };
  
  const handleRichTextChange = (name: string, value: string) => {
    setResumeData(prev => ({
      ...prev,
      personal: { ...prev.personal, [name]: value }
    }));
  };

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setResumeData(prev => ({
          ...prev,
          personal: { ...prev.personal, photo: event.target?.result as string }
        }));
      };
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  const handleSummaryUpdate = (newSummary: string) => {
    setResumeData(prev => ({
      ...prev,
      personal: { ...prev.personal, summary: newSummary }
    }));
  };
  
  return (
    <div className="space-y-4">
       <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input label="Full Name" name="fullName" value={personal.fullName} onChange={handleChange} />
            <Input label="Job Title" name="jobTitle" value={personal.jobTitle} onChange={handleChange} />
            <Input label="Email" name="email" type="email" value={personal.email} onChange={handleChange} />
            <Input label="Phone" name="phone" type="tel" value={personal.phone} onChange={handleChange} />
            <Input label="Address" name="address" value={personal.address} onChange={handleChange} />
            <Input label="Website" name="website" value={personal.website} onChange={handleChange} />
       </div>
       <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Photo
            </label>
            <input
              type="file"
              accept="image/*"
              onChange={handlePhotoChange}
              className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-600 hover:file:bg-indigo-100 dark:file:bg-gray-700 dark:file:text-indigo-300 dark:hover:file:bg-gray-600"
            />
        </div>
        <div className="relative">
            <RichTextInput 
                label="Summary"
                value={personal.summary}
                onChange={(value) => handleRichTextChange('summary', value)}
            />
            <AIAssistButton 
                field="professional summary" 
                context={JSON.stringify({jobTitle: personal.jobTitle})}
                onGeneratedText={handleSummaryUpdate} />
        </div>
    </div>
  );
};
