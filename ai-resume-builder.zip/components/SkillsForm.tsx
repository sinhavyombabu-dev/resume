
import React from 'react';
import type { ResumeData, Skill } from '../types';
import { Input } from './Input';
import { PlusCircleIcon } from './icons/PlusCircleIcon';
import { TrashIcon } from './icons/TrashIcon';

interface SkillsFormProps {
  skills: Skill[];
  setResumeData: React.Dispatch<React.SetStateAction<ResumeData>>;
}

export const SkillsForm: React.FC<SkillsFormProps> = ({ skills, setResumeData }) => {

  const handleChange = (id: string, e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setResumeData(prev => ({
      ...prev,
      skills: prev.skills.map(skill =>
        skill.id === id
          ? { ...skill, [name]: name === 'level' ? parseInt(value, 10) : value }
          : skill
      )
    }));
  };

  const addSkill = () => {
    const newSkill: Skill = {
      id: `skill-${Date.now()}`,
      name: '',
      level: 3
    };
    setResumeData(prev => ({
      ...prev,
      skills: [...prev.skills, newSkill]
    }));
  };

  const removeSkill = (id: string) => {
    setResumeData(prev => ({
      ...prev,
      skills: prev.skills.filter(skill => skill.id !== id)
    }));
  };

  return (
    <div className="space-y-4">
      {skills.map(skill => (
        <div key={skill.id} className="flex items-center space-x-4">
          <div className="flex-grow">
            <Input label="Skill" name="name" value={skill.name} onChange={e => handleChange(skill.id, e)} hideLabel />
          </div>
          <div className="w-1/3">
            <input
              type="range"
              min="1"
              max="5"
              name="level"
              value={skill.level}
              onChange={e => handleChange(skill.id, e)}
              className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700"
            />
          </div>
          <button onClick={() => removeSkill(skill.id)} className="text-red-500 hover:text-red-700">
            <TrashIcon />
          </button>
        </div>
      ))}
      <button onClick={addSkill} className="flex items-center space-x-2 text-indigo-600 hover:text-indigo-800 font-semibold mt-4">
        <PlusCircleIcon />
        <span>Add Skill</span>
      </button>
    </div>
  );
};
