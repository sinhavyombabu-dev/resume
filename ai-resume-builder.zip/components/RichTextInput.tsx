
import React, { useRef } from 'react';

interface RichTextInputProps {
  label: string;
  value: string;
  onChange: (value: string) => void;
}

const ToolbarButton: React.FC<{ onMouseDown: (e: React.MouseEvent) => void, children: React.ReactNode }> = ({ onMouseDown, children }) => (
    <button
        type="button"
        onMouseDown={onMouseDown}
        className="px-2 py-1 border border-gray-300 dark:border-gray-600 rounded text-xs hover:bg-gray-100 dark:hover:bg-gray-700"
    >
        {children}
    </button>
);

export const RichTextInput: React.FC<RichTextInputProps> = ({ label, value, onChange }) => {
    const editorRef = useRef<HTMLDivElement>(null);

    const handleCommand = (e: React.MouseEvent, command: string) => {
        e.preventDefault();
        document.execCommand(command, false);
        if (editorRef.current) {
            onChange(editorRef.current.innerHTML);
        }
    };

    const handleBlur = () => {
        if (editorRef.current) {
            onChange(editorRef.current.innerHTML);
        }
    };

    return (
        <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                {label}
            </label>
            <div className="rounded-md shadow-sm border border-gray-300 dark:border-gray-600">
                <div className="flex items-center space-x-2 p-2 border-b border-gray-300 dark:border-gray-600 bg-gray-50 dark:bg-gray-700 rounded-t-md">
                    <ToolbarButton onMouseDown={(e) => handleCommand(e, 'bold')}><b>B</b></ToolbarButton>
                    <ToolbarButton onMouseDown={(e) => handleCommand(e, 'italic')}><i>I</i></ToolbarButton>
                    <ToolbarButton onMouseDown={(e) => handleCommand(e, 'insertUnorderedList')}>• List</ToolbarButton>
                </div>
                <div
                    ref={editorRef}
                    contentEditable
                    onBlur={handleBlur}
                    dangerouslySetInnerHTML={{ __html: value }}
                    className="block w-full min-h-[100px] px-3 py-2 bg-white dark:bg-gray-800 placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none sm:text-sm rounded-b-md"
                />
            </div>
        </div>
    );
};
