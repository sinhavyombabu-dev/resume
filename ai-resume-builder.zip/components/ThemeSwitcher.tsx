
import React, { useState, useRef, useEffect } from 'react';
import type { Theme } from '../themes';
import { themes } from '../themes';
import { PaletteIcon } from './icons/PaletteIcon';

interface ThemeSwitcherProps {
  activeTheme: Theme;
  setActiveTheme: (theme: Theme) => void;
}

export const ThemeSwitcher: React.FC<ThemeSwitcherProps> = ({ activeTheme, setActiveTheme }) => {
  const [isOpen, setIsOpen] = useState(false);
  const wrapperRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [wrapperRef]);
  
  const handleSelectTheme = (theme: Theme) => {
    setActiveTheme(theme);
    setIsOpen(false);
  };

  return (
    <div className="relative" ref={wrapperRef}>
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center space-x-2 border border-gray-300 dark:border-gray-600 px-3 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700"
      >
        <PaletteIcon />
        <span className="hidden md:inline text-sm font-medium">{activeTheme.name}</span>
      </button>
      {isOpen && (
        <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-gray-800 rounded-md shadow-lg z-10 border dark:border-gray-700">
          <ul className="py-1">
            {themes.map(theme => (
              <li key={theme.name}>
                <button
                  onClick={() => handleSelectTheme(theme)}
                  className="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700"
                >
                  {theme.name}
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};
