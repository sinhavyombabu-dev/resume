
import React from 'react';
import type { ResumeData, SectionKey } from '../types';
import { MailIcon } from './icons/MailIcon';
import { PhoneIcon } from './icons/PhoneIcon';
import { LinkIcon } from './icons/LinkIcon';
import { LocationIcon } from './icons/LocationIcon';

interface ResumePreviewProps {
  resumeData: ResumeData;
  themeClassName: string;
  sectionOrder: SectionKey[];
}

const SkillBar: React.FC<{ level: number }> = ({ level }) => (
    <div className="w-full bg-gray-200 rounded-full h-1.5 dark:bg-gray-700 skill-bar-bg">
        <div className="h-1.5 rounded-full primary-bg skill-bar-fill" style={{ width: `${level * 20}%` }}></div>
    </div>
);


export const ResumePreview: React.FC<ResumePreviewProps> = ({ resumeData, themeClassName, sectionOrder }) => {
  const { personal, experience, education, skills, customSections } = resumeData;

  const sectionComponents = {
    experience: (
        <section key="experience">
            <h3 className="text-lg font-bold primary-color border-color pb-1 mb-3 section-title">Experience</h3>
            <div className="space-y-6">
              {experience.map(exp => (
                <div key={exp.id}>
                  <div className="flex justify-between items-baseline">
                    <h4 className="font-bold text-base">{exp.jobTitle}</h4>
                    <div className="text-xs font-mono text-gray-500 dark:text-gray-400">{exp.startDate} - {exp.endDate}</div>
                  </div>
                  <div className="flex justify-between items-baseline text-sm">
                    <p className="font-semibold primary-color">{exp.company}</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">{exp.location}</p>
                  </div>
                  <div className="mt-2 text-gray-700 dark:text-gray-300 space-y-1 text-sm prose prose-sm max-w-none" dangerouslySetInnerHTML={{ __html: exp.description }}/>
                </div>
              ))}
            </div>
        </section>
    ),
    education: (
        <section key="education">
            <h3 className="text-lg font-bold primary-color border-color pb-1 mb-3 section-title">Education</h3>
            <div className="space-y-4">
              {education.map(edu => (
                <div key={edu.id}>
                  <h4 className="font-bold">{edu.degree}</h4>
                  <p className="primary-color font-semibold">{edu.institution}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">{edu.location}</p>
                  <p className="text-xs font-mono text-gray-500 dark:text-gray-400 mt-1">{edu.startDate} - {edu.endDate}</p>
                </div>
              ))}
            </div>
        </section>
    ),
    skills: (
        <section key="skills">
            <h3 className="text-lg font-bold primary-color border-color pb-1 mb-3 section-title">Skills</h3>
            <div className="space-y-3">
              {skills.map(skill => (
                <div key={skill.id}>
                  <p className="font-semibold mb-1">{skill.name}</p>
                  <SkillBar level={skill.level} />
                </div>
              ))}
            </div>
        </section>
    ),
    ...customSections.reduce((acc, section) => {
        acc[section.id] = (
            <section key={section.id}>
              <h3 className="text-lg font-bold primary-color border-color pb-1 mb-3 section-title">{section.title}</h3>
              <div className="text-gray-700 dark:text-gray-300 prose prose-sm max-w-none" dangerouslySetInnerHTML={{ __html: section.content }} />
            </section>
        );
        return acc;
// FIX: Use React.ReactElement instead of JSX.Element to resolve namespace issue.
    }, {} as Record<string, React.ReactElement>)
  };

  const mainContentOrder = sectionOrder.filter(key => ['experience'].includes(key) || key.startsWith('custom-'));
  const sidebarContentOrder = sectionOrder.filter(key => ['skills', 'education'].includes(key));

  return (
    <div id="resume-to-print" className={`w-full max-w-[8.5in] min-h-[11in] bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-200 shadow-lg p-8 md:p-12 text-sm print:shadow-none print:p-10 resume-container ${themeClassName}`}>
      <header className="flex items-start space-x-6 mb-8 header-layout">
        {personal.photo && (
            <img src={personal.photo} alt="Profile" className="w-24 h-24 rounded-full object-cover flex-shrink-0" />
        )}
        <div className="flex-grow header-content flex flex-col">
            <h1 className="font-bold primary-color name">{personal.fullName}</h1>
            <h2 className="text-xl font-semibold text-gray-700 dark:text-gray-300 mt-1 job-title">{personal.jobTitle}</h2>
        </div>
      </header>
      
      <div className="flex items-center justify-start space-x-6 mb-8 text-xs border-y py-3 border-color contact-info">
        <div className="flex items-center space-x-2"><MailIcon className="w-3 h-3 primary-color"/><a href={`mailto:${personal.email}`} className="hover:underline">{personal.email}</a></div>
        <div className="flex items-center space-x-2"><PhoneIcon className="w-3 h-3 primary-color"/><span>{personal.phone}</span></div>
        <div className="flex items-center space-x-2"><LocationIcon className="w-3 h-3 primary-color"/><span>{personal.address}</span></div>
        <div className="flex items-center space-x-2"><LinkIcon className="w-3 h-3 primary-color"/><a href={personal.website} target="_blank" rel="noopener noreferrer" className="hover:underline">{personal.website}</a></div>
      </div>


      <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
        <div className="md:col-span-2 space-y-8">
          <section>
            <h3 className="text-lg font-bold primary-color border-color pb-1 mb-3 section-title">Summary</h3>
            <div className="text-gray-700 dark:text-gray-300 prose prose-sm max-w-none" dangerouslySetInnerHTML={{ __html: personal.summary }} />
          </section>

          {mainContentOrder.map(key => sectionComponents[key])}
        </div>
        
        <div className="md:col-span-1 space-y-8">
            {sidebarContentOrder.map(key => sectionComponents[key])}
        </div>
      </div>
    </div>
  );
};
