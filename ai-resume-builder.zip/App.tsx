
import React, { useState, useEffect, useMemo } from 'react';
import { ResumeForm } from './components/ResumeForm';
import { ResumePreview } from './components/ResumePreview';
import type { ResumeData, SectionKey } from './types';
import { initialResumeData } from './constants';
import { PrintIcon } from './components/icons/PrintIcon';
import { ThemeSwitcher } from './components/ThemeSwitcher';
import { themes, themeStyles } from './themes';
import type { Theme } from './themes';
import { initialSectionOrder } from './constants';

function App() {
  const [resumeData, setResumeData] = useState<ResumeData>(initialResumeData);
  const [activeTheme, setActiveTheme] = useState<Theme>(themes[0]);
  const [mobileView, setMobileView] = useState<'editor' | 'preview'>('editor');
  const [sectionOrder, setSectionOrder] = useState<SectionKey[]>(initialSectionOrder);
  
  const [draggedItem, setDraggedItem] = useState<SectionKey | null>(null);
  const [dragOverItem, setDragOverItem] = useState<SectionKey | null>(null);

  useEffect(() => {
    const styleEl = document.getElementById('resume-themes');
    if (styleEl) {
      styleEl.innerHTML = themeStyles;
    }
  }, []);

  const handlePrint = () => {
    const resumeEl = document.getElementById('resume-to-print');
    if (!resumeEl) {
      console.error('Resume element not found for printing.');
      return;
    }

    // 1. Create a hidden iframe
    const iframe = document.createElement('iframe');
    iframe.style.position = 'absolute';
    iframe.style.width = '0';
    iframe.style.height = '0';
    iframe.style.border = 'none';

    // 2. Set up the onload event handler
    iframe.onload = () => {
      if (!iframe.contentWindow) return;

      // 4. Trigger print after the iframe has loaded all content
      iframe.contentWindow.focus();
      iframe.contentWindow.print();

      // 5. Remove the iframe after the print dialog is closed.
      // The print() command is blocking, so this will execute after.
      setTimeout(() => {
        if (document.body.contains(iframe)) {
          document.body.removeChild(iframe);
        }
      }, 100);
    };
    
    // 3. Append the iframe and write the document content
    document.body.appendChild(iframe);
    const doc = iframe.contentWindow?.document;

    if (!doc) {
      console.error('Could not access iframe document.');
      document.body.removeChild(iframe);
      return;
    }
    
    // Write the full HTML structure. doc.close() will trigger iframe.onload
    doc.open();
    doc.write(`<!DOCTYPE html><html><head>${document.head.innerHTML}</head><body>${resumeEl.outerHTML}</body></html>`);
    doc.close();
  };

  const handleDragStart = (key: SectionKey) => {
    setDraggedItem(key);
  };

  const handleDragOver = (e: React.DragEvent, key: SectionKey) => {
    e.preventDefault();
    if (key !== dragOverItem) {
      setDragOverItem(key);
    }
  };
  
  const handleDrop = (targetKey: SectionKey) => {
    if (!draggedItem || draggedItem === targetKey) return;

    const draggedIndex = sectionOrder.findIndex(key => key === draggedItem);
    const targetIndex = sectionOrder.findIndex(key => key === targetKey);

    const newOrder = [...sectionOrder];
    const [removed] = newOrder.splice(draggedIndex, 1);
    newOrder.splice(targetIndex, 0, removed);

    setSectionOrder(newOrder);
    setDraggedItem(null);
    setDragOverItem(null);
  };
  
  const handleDragEnd = () => {
      setDraggedItem(null);
      setDragOverItem(null);
  }

  // Update section order if custom sections are added/deleted
  useEffect(() => {
    const customSectionKeys = resumeData.customSections.map(s => s.id);
    const newKeys = initialSectionOrder.filter(k => !k.startsWith('custom-')).concat(customSectionKeys);

    // Keep existing order for existing keys, append new ones
    setSectionOrder(currentOrder => {
      const orderedExisting = currentOrder.filter(k => newKeys.includes(k));
      const addedKeys = newKeys.filter(k => !orderedExisting.includes(k));
      return [...orderedExisting, ...addedKeys];
    });
  }, [resumeData.customSections]);


  return (
    <div className="min-h-screen font-sans text-gray-800 dark:text-gray-200">
      <header className="bg-white dark:bg-gray-800 shadow-md p-4 flex justify-between items-center no-print">
        <div className="flex items-center space-x-2">
           <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="_0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-indigo-600"><path d="M15.5 2H8.6c-.4 0-.8.2-1.1.5-.3.3-.5.7-.5 1.1v12.8c0 .4.2.8.5 1.1.3.3.7.5 1.1.5h9.8c.4 0 .8-.2 1.1-.5.3-.3.5-.7.5-1.1V6.5L15.5 2z"/><path d="M3 7.6v12.8c0 .4.2.8.5 1.1.3.3.7.5 1.1.5h9.8"/><path d="M15 2v5h5"/></svg>
          <h1 className="text-xl md:text-2xl font-bold text-gray-900 dark:text-white">AI Resume Builder</h1>
        </div>
        <div className="flex items-center space-x-2 md:space-x-4">
          <ThemeSwitcher activeTheme={activeTheme} setActiveTheme={setActiveTheme} />
          <button
            onClick={handlePrint}
            className="flex items-center space-x-2 bg-indigo-600 text-white px-4 py-2 rounded-lg font-semibold hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors"
          >
            <PrintIcon />
            <span className="hidden md:inline">Print / PDF</span>
          </button>
        </div>
      </header>
      <main className="grid grid-cols-1 lg:grid-cols-2 min-h-[calc(100vh-6rem)] relative">
        <div className={`w-full p-4 md:p-8 no-print overflow-y-auto h-[calc(100vh-10rem)] lg:h-[calc(100vh-4.5rem)] ${mobileView === 'preview' ? 'hidden' : ''} lg:block`}>
          <ResumeForm 
            resumeData={resumeData} 
            setResumeData={setResumeData} 
            sectionOrder={sectionOrder}
            draggedItem={draggedItem}
            dragOverItem={dragOverItem}
            onDragStart={handleDragStart}
            onDragOver={handleDragOver}
            onDrop={handleDrop}
            onDragEnd={handleDragEnd}
          />
        </div>
        <div className={`w-full bg-gray-200 dark:bg-gray-800 p-4 md:p-8 flex items-start justify-center overflow-y-auto h-full lg:h-[calc(100vh-4.5rem)] print-area ${mobileView === 'editor' ? 'hidden' : ''} lg:flex`}>
          <ResumePreview resumeData={resumeData} themeClassName={activeTheme.className} sectionOrder={sectionOrder} />
        </div>

        <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 border-t dark:border-gray-700 grid grid-cols-2 gap-px no-print">
            <button onClick={() => setMobileView('editor')} className={`py-3 text-sm font-medium ${mobileView === 'editor' ? 'bg-indigo-50 dark:bg-indigo-900 text-indigo-600 dark:text-indigo-300' : 'text-gray-600 dark:text-gray-300'}`}>Editor</button>
            <button onClick={() => setMobileView('preview')} className={`py-3 text-sm font-medium ${mobileView === 'preview' ? 'bg-indigo-50 dark:bg-indigo-900 text-indigo-600 dark:text-indigo-300' : 'text-gray-600 dark:text-gray-300'}`}>Preview</button>
        </div>
      </main>
    </div>
  );
}

export default App;
