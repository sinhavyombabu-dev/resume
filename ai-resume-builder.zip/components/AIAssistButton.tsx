
import React, { useState } from 'react';
import { AIModal } from './AIModal';
import { SparklesIcon } from './icons/SparklesIcon';

interface AIAssistButtonProps {
  field: string;
  context: string;
  onGeneratedText: (text: string) => void;
}

export const AIAssistButton: React.FC<AIAssistButtonProps> = ({ field, context, onGeneratedText }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleInsertText = (text: string) => {
    onGeneratedText(text);
    setIsModalOpen(false);
  };

  return (
    <>
      <button
        type="button"
        onClick={() => setIsModalOpen(true)}
        className="absolute bottom-2 right-2 flex items-center space-x-1 text-xs bg-indigo-100 dark:bg-indigo-900 text-indigo-600 dark:text-indigo-300 px-2 py-1 rounded-md hover:bg-indigo-200 dark:hover:bg-indigo-800"
      >
        <SparklesIcon />
        <span>AI Assist</span>
      </button>
      {isModalOpen && (
        <AIModal
          field={field}
          context={context}
          onClose={() => setIsModalOpen(false)}
          onInsertText={handleInsertText}
        />
      )}
    </>
  );
};
